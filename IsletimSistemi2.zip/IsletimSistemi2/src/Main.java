import java.util.ArrayList;
import java.util.List;

public class Main {
	private static final List<Integer> ciftSayilar = new ArrayList<>();
	private static final List<Integer> tekSayilar = new ArrayList<>();
	private static final List<Integer> asalSayilar = new ArrayList<>();

	public static void main(String[] args) throws InterruptedException {
		List<Integer> tumSayilar = new ArrayList<>();
		for (int i = 1; i <= 1_000_000; i++) {
			tumSayilar.add(i);
		}

		int parcaBoyutu = 25000;
		Thread[] threadler = new Thread[120];

		Object ciftLock = new Object();
		Object tekLock = new Object();
		Object asalLock = new Object();

		for (int i = 0; i < 40; i++) {
			int baslangic = i * parcaBoyutu;
			int bitis = Math.min(baslangic + parcaBoyutu, tumSayilar.size());
			List<Integer> parca = new ArrayList<>(tumSayilar.subList(baslangic, bitis));
			threadler[i] = new Thread(new CiftSayiBulucu(parca, ciftSayilar, ciftLock));
			threadler[i].start();
		}

		for (int i = 40; i < 80; i++) {
			int baslangic = (i - 40) * parcaBoyutu;
			int bitis = Math.min(baslangic + parcaBoyutu, tumSayilar.size());
			List<Integer> parca = new ArrayList<>(tumSayilar.subList(baslangic, bitis));
			threadler[i] = new Thread(new TekSayiBulucu(parca, tekSayilar, tekLock));
			threadler[i].start();
		}

		for (int i = 80; i < 120; i++) {
			int baslangic = (i - 80) * parcaBoyutu;
			int bitis = Math.min(baslangic + parcaBoyutu, tumSayilar.size());
			List<Integer> parca = new ArrayList<>(tumSayilar.subList(baslangic, bitis));
			threadler[i] = new Thread(new AsalSayiBulucu(parca, asalSayilar, asalLock));
			threadler[i].start();
		}

		for (Thread t : threadler) {
			t.join();
		}

		System.out.println("Çift sayılar listesi boyutu: " + ciftSayilar.size());
		System.out.println("Tek sayılar listesi boyutu: " + tekSayilar.size());
		System.out.println("Asal sayılar listesi boyutu: " + asalSayilar.size());
	}
}
