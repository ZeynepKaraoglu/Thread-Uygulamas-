import java.util.List;

public class AsalSayiBulucu implements Runnable {
	private final List<Integer> sayilar;
	private final List<Integer> asalSayilar;
	private final Object lock;

	public AsalSayiBulucu(List<Integer> sayilar, List<Integer> asalSayilar, Object lock) {
		this.sayilar = sayilar;
		this.asalSayilar = asalSayilar;
		this.lock = lock;
	}

	@Override
	public void run() {
		for (int sayi : sayilar) {
			if (isAsal(sayi)) {
				synchronized (lock) {
					asalSayilar.add(sayi);
				}
			}
		}
	}

	private boolean isAsal(int sayi) {
		if (sayi <= 1) {
			return false;
		}
		for (int i = 2; i * i <= sayi; i++) {
			if (sayi % i == 0) {
				return false;
			}
		}
		return true;
	}
}
