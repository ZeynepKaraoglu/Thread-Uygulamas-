import java.util.List;

public class TekSayiBulucu implements Runnable {
	private final List<Integer> sayilar;
	private final List<Integer> tekSayilar;
	private final Object lock;

	public TekSayiBulucu(List<Integer> sayilar, List<Integer> tekSayilar, Object lock) {
		this.sayilar = sayilar;
		this.tekSayilar = tekSayilar;
		this.lock = lock;
	}

	@Override
	public void run() {
		for (int sayi : sayilar) {
			if (sayi % 2 != 0) {
				synchronized (lock) {
					tekSayilar.add(sayi);
				}
			}
		}
	}
}
