import java.util.List;

public class CiftSayiBulucu implements Runnable {
	private final List<Integer> sayilar;
	private final List<Integer> ciftSayilar;
	private final Object lock;

	public CiftSayiBulucu(List<Integer> sayilar, List<Integer> ciftSayilar, Object lock) {
		this.sayilar = sayilar;
		this.ciftSayilar = ciftSayilar;
		this.lock = lock;
	}

	@Override
	public void run() {
		for (int sayi : sayilar) {
			if (sayi % 2 == 0) {
				synchronized (lock) {
					ciftSayilar.add(sayi);
				}
			}
		}
	}
}
